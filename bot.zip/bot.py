import asyncio
import logging
from datetime import datetime, timedelta
from telegram import Bot, Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters

# Настройки
BOT_TOKEN = "8632937242:AAEP1Z7qgCSBFEQsatnW1xrOfIsa_trFafg"
CHAT_ID = -1002872329127
TIMEZONE_OFFSET = timedelta(hours=3)  # UTC+3 (Москва)
REMINDER_INTERVAL = 1800  # 30 минут в секундах (1800 секунд)

# Состояние бота
current_admin = None
start_time = None
pinned_message_id = None
reminder_sent = False  # Флаг: было ли отправлено напоминание

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def send_and_pin_message(bot: Bot, text: str) -> int:
    """Отправляет сообщение и закрепляет его, возвращает ID сообщения"""
    message = await bot.send_message(chat_id=CHAT_ID, text=text)
    await bot.pin_chat_message(chat_id=CHAT_ID, message_id=message.message_id)
    return message.message_id

async def unpin_message(bot: Bot):
    """Открепляет текущее закреплённое сообщение"""
    global pinned_message_id
    if pinned_message_id:
        try:
            await bot.unpin_chat_message(chat_id=CHAT_ID, message_id=pinned_message_id)
        except Exception as e:
            logger.error(f"Ошибка при откреплении сообщения: {e}")
        pinned_message_id = None

async def start_shift(update: Update, context):
    """Начинает смену админа"""
    global current_admin, start_time, pinned_message_id, reminder_sent

    user = update.message.from_user
    username = user.username or user.first_name

    if current_admin:
        if current_admin == username:
            await update.message.reply_text(f'"{username}", вы уже на смене!')
        else:
            await update.message.reply_text('Смена уже открыта другим админом. Будьте внимательнее')
        return

    # Открепляем старое сообщение о свободной смене, если оно есть
    await unpin_message(context.bot)

    # Начинаем новую смену и сбрасываем флаг напоминания
    current_admin = username
    start_time = datetime.utcnow() + TIMEZONE_OFFSET
    reminder_sent = False  # Сбрасываем флаг при начале новой смены
    time_str = start_time.strftime('%H:%M')

    pinned_message_id = await send_and_pin_message(
        context.bot,
        f'В чате админит: "{username}"\nНачало: {time_str}'
    )

async def end_shift(update: Update, context, force=False):
    """Завершает смену админа"""
    global current_admin, start_time, pinned_message_id, reminder_sent

    if not current_admin:
        await update.message.reply_text('Сейчас нет активной смены')
        return

    user = update.message.from_user
    username = user.username or user.first_name

    # Проверка: только текущий админ может закрыть смену (если не принудительно)
    if not force and current_admin != username:
        await update.message.reply_text('Вы не можете закрыть чужую смену.')
        return

    # Если принудительное завершение, используем имя текущего админа
    if force:
        username = current_admin

    end_time = datetime.utcnow() + TIMEZONE_OFFSET
    duration = end_time - start_time
    hours, remainder = divmod(int(duration.total_seconds()), 3600)
    minutes, _ = divmod(remainder, 60)

    # Открепляем старое сообщение
    await unpin_message(context.bot)

    # Отправляем сообщение о завершении
    duration_text = f'{hours:02d}:{minutes:02d}' if hours > 0 else f'{minutes} мин'
    await context.bot.send_message(
        chat_id=CHAT_ID,
        text=f'"{username}" вышел из чата. Смена длилась: {duration_text}'
    )

    # Закрепляем сообщение о свободной смене
    pinned_message_id = await send_and_pin_message(
        context.bot,
        'Смена свободна. Админ в поиске...'
    )

    # Сбрасываем состояние
    current_admin = None
    start_time = None
    reminder_sent = False  # Сбрасываем флаг при завершении смены

async def force_end_shift(update: Update, context):
    """Принудительно завершает смену"""
    await end_shift(update, context, force=True)

async def check_reminder(context):
    """Проверяет необходимость напоминания каждые 30 минут, отправляет только один раз"""
    global reminder_sent

    # Если админ есть или напоминание уже было отправлено — выходим
    if current_admin or reminder_sent:
        return

    # Отправляем напоминание и устанавливаем флаг
    await context.bot.send_message(
        chat_id=CHAT_ID,
        text='Чат сейчас без админа. Кто может зайти?'
    )
    reminder_sent = True

async def handle_messages(update: Update, context):
    """Обрабатывает входящие сообщения"""
    text = update.message.text.lower()

    # Начало смены
    if text in ['иду в чат', 'я в чат']:
        await start_shift(update, context)

    # Конец смены
    elif text in ['выхожу из чата', 'вышел из чата', 'вышла из чата']:
        await end_shift(update, context)

def main():
    """Основная функция запуска бота"""
    application = Application.builder().token(BOT_TOKEN).build()

    # Обработчики команд
    application.add_handler(CommandHandler("ex", force_end_shift))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_messages))

    # Настраиваем напоминание каждые 30 минут
    job_queue = application.job_queue
    job_queue.run_repeating(check_reminder, interval=REMINDER_INTERVAL, first=10)

    # Запускаем бота
    application.run_polling()

if __name__ == '__main__':
    main()
